import React from "react"

function App() {
  return (
    <div className="App">
      <h1>Admin</h1>
    </div>
  )
}

export default App
