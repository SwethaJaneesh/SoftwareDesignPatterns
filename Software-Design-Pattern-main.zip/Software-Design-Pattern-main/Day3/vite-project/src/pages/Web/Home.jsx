import React from 'react'
const Home = () => {
  return (
    <div className='h-full w-full flex justify-center items-center'>
      <h1>Home</h1>
    </div>
  )
}

export default Home