import React from 'react'

const Adminlayout = () => {
  return (
    <div>Adminlayout</div>
  )
}

export default Adminlayout