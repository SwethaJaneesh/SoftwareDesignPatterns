import React from 'react'

const Userlayout = () => {
  return (
    <div>Userlayout</div>
  )
}

export default Userlayout