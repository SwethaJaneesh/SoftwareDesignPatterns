import React from 'react'

const Leftbar = () => {
  return (
    <div className='h-screen w-1/4 flex justify-center items-center'>
        <div>
            links
        </div>
        <div>
            links
        </div>
        <div>
            logout
        </div>
    </div>
  )
}

export default Leftbar