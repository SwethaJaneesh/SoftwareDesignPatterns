package com.max.quizspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizspringApplication.class, args);
	}

}
