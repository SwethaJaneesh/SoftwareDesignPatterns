package com.max.quizspring.enums;

public enum TokenType {
    BEARER
}